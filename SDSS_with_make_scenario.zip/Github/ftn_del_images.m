function [] = ftn_del_images()
for ii =1: 500
    if mod(ii, 2) ~= 0
delete(sprintf('%d.jpg',ii));
    end 
end 