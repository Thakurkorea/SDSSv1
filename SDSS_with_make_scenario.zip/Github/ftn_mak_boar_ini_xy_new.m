function [grid_x, grid_y] = ftn_mak_boar_ini_xy_new()

            [fileName, pathName] = uigetfile({'*.xlsx';'*.xls'}, 'Select Exel File');
            currentFolder = pwd; % save the current location
            cd(pathName);
            [numbers, text, ini_pos_boar] = xlsread(fileName);
            cd(currentFolder);
            a = ini_pos_boar([2: end], [2: 3]);
            boar_xy = cell2mat(a);
            
% boar_xy = xlsread('wild_boar.xlsx');
in_lat = boar_xy(:,1);
in_long = boar_xy(:,2);
space_size = 500;
grid_x = [];
grid_y = [];
n_b = length(boar_xy);
for k = 1: n_b
[g_x, g_y] = ftn_lat_long_to_xy(in_lat(k), in_long(k), space_size);
grid_x(k) = g_x;
grid_y(k) = g_y;
end 
boar_ini_xy = [grid_x', grid_y'];

if isfile('boar_ini_xy.mat') == 1
delete boar_ini_xy.mat
end
save boar_ini_xy.mat boar_ini_xy 