clear
clc 
    
function [] = ftn_mak_scenario()
%% ?쟾�?�?吏??룄 �??
% Map_food = load('Map_Food.tif');
% Map_forest = load('Map_Forest.tif');
% Map_water = load('Map_Water.tif');
% Map_water = load('Map_Water.tif ');
load Maps_takur.mat;
%[Map_total] = ftn_mak_total_map(); % 맵�?� 만드는 함수
%
% load Maps_fense.mat;
% ?떆裕щ젅?씠?뀡 �?��?�린 議곌굔
[numbers, strings, ini_infor] = xlsread('INI_CONDITION.xlsx');
ini_infor(1, :) = [];

end_time = cell2mat(ini_infor(1,2)); %365*1; % ?떆裕щ젅?씠?뀡 ?떆媛? 365*1 --> 1 year
[space_size, w]= size(Map_total); % 怨듦컙?겕湲?
num_boar = cell2mat(ini_infor(2,2)); % ?쟾泥대뤌吏? 媛쒖껜?닔
num_boar_female = cell2mat(ini_infor(3,2)); % ?븫硫�?�뤌吏??쓽 媛쒖껜?닔: 理쒕?媛믪? "?쟾泥대뤌吏??닔-1" ?씠?떎.
num_boar_infected =cell2mat(ini_infor(4,2)); % 媛먯뿼?뤌吏??닔
num_hunter = cell2mat(ini_infor(5,2)); % ?궗?깷�?쇱닔
H = cell2mat(ini_infor(6,2)); % 1.0; % heterogeneous map
boar_walking_noise = cell2mat(ini_infor(7,2)); %0.1; %0.0;  %[0-1] [?쓬?닔?씠硫?--> ?쟾寃⑹옄 怨듦컙?씠 0.5:homogeneous]
deg_escape_hunter = cell2mat(ini_infor(8,2)); %10; % ?궗?깷�?? 媛먯??븯硫? 諛섎?諛⑺뼢?�?濡? ?룄�?앷??뒗 嫄곕�?
P_h_jump = cell2mat(ini_infor(9,2)); % ?궗?깷�?쇱쓽 怨듦컙 ?�??봽
P_h_kill = cell2mat(ini_infor(10,2));  % ?궗?깷�?? ?�?�?뿭?븞?쓽 硫�?�뤌吏? ?궗?궡 ?솗瑜?
P_escape = cell2mat(ini_infor(11,2));  % 
sensing_r_hunter = cell2mat(ini_infor(12,2)); % 
% 
[boar] = ftn_boar_property(num_boar, space_size, num_boar_infected,num_boar_female,P_h_kill);

% 
[boar, num_boar] = ftn_boar_del_in_north_area(boar, num_boar,Map_total, space_size);

% 
% %% *********************************************************
[sens_map] = ftn_sensing_save(boar(1).sensing_r, Map_total);

if num_hunter > 0
    %[hunter, Map_hunter, Map_hunter_mind] = ftn_hunter_property(num_hunter, space_size, Map_total,P_h_jump); % "0"--> ?깶?깷�??
    [hunter, Map_hunter, Map_hunter_mind] = ftn_hunter_property_new(num_hunter, space_size,Map_total, P_h_jump, sensing_r_hunter);
end

[hsens_map] = ftn_sensing_save(sensing_r_hunter, Map_total);



save scenario_11111111111111.mat