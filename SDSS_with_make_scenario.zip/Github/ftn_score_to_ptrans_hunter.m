function [P_trans] = ftn_score_to_ptrans_hunter(hunter_num, score_hunter_mind)

%% �������� --> �̵�Ȯ�� ���
[ordered_score_hunter_mind]=ftn_score_order(score_hunter_mind);
%[ordered_score_rand] = randi([1 9],3,3);

tot_score = (ordered_score_hunter_mind);
                 
T= sum(sum(tot_score));
P_trans = tot_score./T; 
