function [hunter_x, hunter_y] =ftn_hunter_walk(hunter, num, Map_hunter_mind, space_size)
%% ����� �̿����ڵ��� ���� ����

if hunter(num).p_jump > rand(1)
    hunter(num).position(1)= randi([1 space_size-1],1,1);
    hunter(num).position(2)= randi([1 space_size-1],1,1);
    hunter_x = hunter(num).position(1);
    hunter_y = hunter(num).position(2);
    
else
    
    hunter_x = hunter(num).position(1);
    hunter_y = hunter(num).position(2);
    sensing_r = hunter(num).sensing_r;
    [score_hunter_mind] = ftn_score_hunter(hunter_x,hunter_y,sensing_r,Map_hunter_mind);
    %
    %% �������� --> �̵�Ȯ�� ���
    hunter_num = hunter(num);
    [P_trans] = ftn_score_to_ptrans_hunter(hunter_num, score_hunter_mind);
    
    % example:
    % P_trans =...
    %     [0.0296    0.0499    0.0703
    %     0.0907    0.1111    0.1315
    %     0.1519    0.1723    0.1927];
    
    r_1 = P_trans(1,1);
    r_2 = r_1 + P_trans(2,1);
    r_3 = r_2 + P_trans(3,1);
    r_4 = r_3 + P_trans(1,2);
    r_5 = r_4 + P_trans(2,2);
    r_6 = r_5 + P_trans(3,2);
    r_7 = r_6 + P_trans(1,3);
    r_8 = r_7 + P_trans(2,3);
    r_9 = r_8 + P_trans(3,3);
    
    dice = rand(1);
    
    if (dice>=0) & (dice <= r_1)
        hunter_x =hunter_x-1; hunter_y = hunter_y+1;  % ���� 1
    elseif (dice>r_1) & (dice <= r_2)
        hunter_x =hunter_x-1; hunter_y = hunter_y+0; %���� 2
    elseif (dice>r_2) & (dice <= r_3)
        hunter_x =hunter_x-1; hunter_y = hunter_y-1; %���� 3
    elseif (dice>r_3) & (dice <= r_4)
        hunter_x =hunter_x-0; hunter_y = hunter_y+1; %���� 4
    elseif (dice>r_4) & (dice <= r_5)
        hunter_x =hunter_x-0; hunter_y = hunter_y+0; %���� 5
    elseif (dice>r_5) & (dice <= r_6)
        hunter_x =hunter_x-0; hunter_y = hunter_y-1; %���� 6
    elseif (dice>r_6) & (dice <= r_7)
        hunter_x =hunter_x+1; hunter_y = hunter_y+1; % ���� 7
    elseif (dice>r_7) & (dice <= r_8)
        hunter_x =hunter_x+1; hunter_y = hunter_y+0; %���� 8
    elseif (dice>r_8) & (dice <= r_9)
        hunter_x =hunter_x+1; hunter_y = hunter_y-1; %���� 9
    end
    
    
    
end %if P_hunter_jump


