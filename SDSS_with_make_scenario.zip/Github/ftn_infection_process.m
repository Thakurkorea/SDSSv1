function [boar] = ftn_infection_process(boar)
n = length(boar); % 개체 수
if n > 0
load boar_infection.mat
%% 개체 위치
for k = 1:n
a(k) = boar(k).position(1);
b(k) = boar(k).position(2);
end
individual_x = a';
individual_y = b';

%% 개체들간 거리
D_x = ones(n,1) * individual_x' - individual_x * ones(1,n);
D_y = ones(n,1) * individual_y' - individual_y * ones(1,n);
Dsq = D_x .* D_x + D_y .* D_y + eye(n);
D = sqrt(Dsq);
D = sqrt(Dsq)-diag(diag(D)); % 대각성분을 0으로 만듬
U = triu(D); % 삼각행렬 윗부분을 취함.
%% 서로 감염거리 내에 있는 개체쌍 찾기
[p, q] = find((U <= boar_infection_radius) & (U > 0)); 
pairs = [p, q];
y =0; yy=0;
if length(p) > 0
for k = 1: length(p)
if (boar(p(k)).infection ==1) || (boar(q(k)).infection ==1)

if rand(1) < boar_infection_prob
    boar(p(k)).infection = 1;
    boar(q(k)).infection = 1;
end
end
end % for k
end % if length(p)
end % if n > 0