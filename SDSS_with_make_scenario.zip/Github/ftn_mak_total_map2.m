function [Map_total] = ftn_mak_total_map2()
load  Maps_1000_seo.mat  % 해상도 1격자= 1,000미터, 
Map_Food(Map_Food == 0) =1; Map_Food(Map_Foo, Map_Fored == 127) =0.5; Map_Food(Map_Food == 255) =0;
Map_Water(Map_Water == 255) =0;  Map_Water(Map_Water == 127) =0.5; Map_Water(Map_Water == 64) = 0.5; Map_Water(Map_Water == 0) = 0;
Map_Fore(Map_Fore == 0) = 1.0; Map_Fore(Map_Fore == 255) = 0;
Map_food = Map_Food;
Map_water = Map_Water;
Map_forest = Map_Fore;
Map_total = double(Map_food) + double(Map_water) + double(Map_forest);
%