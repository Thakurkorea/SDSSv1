function [p,q] = ftn_mouse_click_line_draw(num)
% num: 마우스로 클릭하고자 하는 점의 갯수
% p, q: 마우스로 클릭한 위치의 좌표값
p=[]; % 변수초기화
q=[];
figure
axis([0 1 0 1]);
for k=1:num
    [x1,y1]=ginput(1);
    p(k,:)=x1;
    q(k,:)=y1;
    if k>1
    plot([x x1],[y y1],'b.-');
    end 
    hold on
    x=x1;y=y1;
end

