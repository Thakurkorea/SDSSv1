clc
clear 
function [] = ftn_mak_scenario()
%% 전국지�?� 맵
% Map_food = load('Map_Food.tif');
% Map_forest = load('Map_Forest.tif');
% Map_water = load('Map_Water.tif');
% Map_water = load('Map_Water.tif ');
load Maps_takur.mat;
%[Map_total] = ftn_mak_total_map(); % 맵�?� 만드는 함수
%
% load Maps_fense.mat;
%% 시뮬레�?�션 초기 조건
[numbers, strings, ini_infor] = xlsread('INI_CONDITION.xlsx');
ini_infor(1, :) = [];

end_time = cell2mat(ini_infor(1,2)) %365*1; % 시뮬레�?�션 시간 365*1 --> 1 year
[space_size, w]= size(Map_total); % 공간�?�기
num_boar = cell2mat(ini_infor(2,2)); % 전체�?�지 개체수
num_boar_female = cell2mat(ini_infor(3,2)); % 암멧�?�지�?� 개체수: 최대값�?� "전체�?�지수-1" �?�다.
num_boar_infected =cell2mat(ini_infor(4,2)); % �?염�?�지수
num_hunter = cell2mat(ini_infor(5,2)) ; % 사냥꾼수
H = cell2mat(ini_infor(6,2)); % 1.0; % heterogeneous map
boar_walking_noise = cell2mat(ini_infor(7,2)); %0.1; %0.0;  %[0-1] [�?�수�?�면--> 전격�? 공간�?� 0.5:homogeneous]
deg_escape_hunter = cell2mat(ini_infor(8,2)); %10; % 사냥꾼 �?지하면 반대방향으로 �?��?가는 거리
P_h_jump = cell2mat(ini_infor(9,2)); % 사냥꾼�?� 공간 �?프
P_h_kill = cell2mat(ini_infor(10,2)); % 사냥꾼 �?역안�?� 멧�?�지 사살 확률
P_escape = cell2mat(ini_infor(11,2)); % 
sensing_r_hunter = cell2mat(ini_infor(12,2)); % 
%% 멧�?�지 특성 설정하기 (초기위치 등)
[boar] = ftn_boar_property(num_boar, space_size, num_boar_infected,num_boar_female,P_h_kill);

%% 야�?멧�?�지 초기위치가 남방한계선 윗쪽�?�면 제거하기
[boar, num_boar] = ftn_boar_del_in_north_area(boar, num_boar,Map_total, space_size);

% %% 야�?�?�지�?� 센싱맵 만들기
% %% *********************************************************
[sens_map] = ftn_sensing_save(boar(1).sensing_r, Map_total);
%% 사냥꾼�?� 센싱맵 만들기
if num_hunter > 0
    %[hunter, Map_hunter, Map_hunter_mind] = ftn_hunter_property(num_hunter, space_size, Map_total,P_h_jump); % "0"--> ?깶?깷�??
    [hunter, Map_hunter, Map_hunter_mind] = ftn_hunter_property_new(num_hunter, space_size,Map_total, P_h_jump, sensing_r_hunter);
end

[hsens_map] = ftn_sensing_save(sensing_r_hunter, Map_total);

%   [fileName, pathName] = uigetfile({'*.xlsx';'*.xls'}, 'Select Exel File');
%             currentFolder = pwd; % save the current location
%             cd(pathName);
%             [numbers text fense_infor] = xlsread(fileName);
%             fense_infor(1, :) = [];
%             cd(currentFolder);
%             
%             fense_lat = cell2mat(fense_infor(:, 1));
%             fense_long = cell2mat(fense_infor(:, 2));
%             n = length(fense_lat);
%            
%             if isfile('Maps_fense.mat') % �?�전 펜스 파�?��?� 있으면 삭제
%                delete Maps_fense.mat;
%            else
%                return
%            end
%            space_size = 500;
%             for k = 1: n
%                 [grid_x, grid_y] = ftn_lat_long_to_xy(fense_lat(k), fense_long(k), space_size);
%                 x(k, 1) = grid_x;
%                 y(k, 1) = grid_y;
%                 
%                  % 펜스 설치하기
%             end
%             
%             P_fense = 0.1; %app.EditField_Fense_Prob.Value;
%                 
%             [xs, ys]=ftn_mouse_click_spline_file(P_fense, x, y, n);
%           
%             for k = 1: length(xs)
%             Map_total(ys(k), xs(k)) = P_fense;
%             end
 
save scenario_10000.mat
end
