clear all
clc 
load scenario_7.mat
% this is to insert the fence data in the scenario file 
fence=input('Do you want to consider fence? insert 1 or 0:-'); 
if fence==1

[fileName, pathName] = uigetfile({'*.xlsx';'*.xls'}, 'Select Exel File');
            currentFolder = pwd; % save the current location
            cd(pathName);
            [numbers text fense_infor] = xlsread(fileName, 'Fense');
            [numbers text fense_infor] = xlsread(fileName);

            [numbers text fense_infor] = xlsread('FENSE.xlsx');
            fense_infor(1, :) = [];
            cd(currentFolder);
            
            fense_lat = cell2mat(fense_infor(:, 1));
            fense_long = cell2mat(fense_infor(:, 2));
            n = length(fense_lat);
           
            if isfile('Maps_fense.mat') % �?�전 펜스 파�?��?� 있으면 삭제
               delete Maps_fense.mat;
           else
               return
           end
           space_size = 500;
            for k = 1: n
                [grid_x, grid_y] = ftn_lat_long_to_xy(fense_lat(k), fense_long(k), space_size);
                x(k, 1) = grid_x;
                y(k, 1) = grid_y;
                
                 % 펜스 설치하기
            end
            
            P_fense = 0.1; %app.EditField_Fense_Prob.Value;
                
            [xs, ys]=ftn_mouse_click_spline_file(P_fense, x, y, n);
          
            for k = 1: length(xs)
            Map_total(ys(k),xs(k)) = P_fense;
            end
end            
%% edit the run the code again and save the             
end_time=input('Please insert simulation period :') %2000%  % set simulation time
boar(200:end) = [];  % add or remmove initial boar data 
num_boar=length(boar);
n=length(boar);
carcass_rem_time= input('what is carcass_removal_time?:');
for i=1:n
boar(i).period_infection_to_death= carcass_rem_time;  % carcass_removal_day
boar(i).carcass_persi= boar(i).period_infection_to_death;  % carcass_removal_day
end

% plot the total map and select the points on map
imagesc(Map_total);points= ginput

% boar_infection_prob=0.0015;

%%%% Chage the boar positions 
for ii =1:n;
    x_pos=randi([floor(min(points(:,2))), floor(max(points(:,2)))]);
    y_pos=randi([floor(min(points(:,1))), floor(max(points(:,1)))]);
    boar(ii).position= [y_pos,x_pos,];
end
num_hunter=input('number of hunters:');
% [hunter(1:5).position] = deal([]);

if num_hunter>0;
    for iii=1:num_hunter;
    x_pos=randi([floor(min(points(:,2))), floor(max(points(:,2)))]);
    y_pos=randi([floor(min(points(:,1))), floor(max(points(:,1)))]);
%     x_pos=randi([floor(mean(points(:,2))), floor(mean(points(:,2)))]);
%     y_pos=randi([floor(mean(points(:,1))), floor(mean(points(:,1)))]);
    hunter(iii).position = [y_pos,x_pos+20];
%      hunter(iii).position = [0,0];    % need to adjust
    end
end


for i =1:length(boar);    % to no initial infected boars
if rand<0;
    boar(i).infection=1
else
    boar(i).infection=0;
end
end
p_h_kill=input('what is probability of kill?:');
sensing_r_hunter=input('what is sencing radius?:');
save 'scenario_sr5,hk0.5,car_r48.mat'
% imagesc(Map_total)

