function [hunter, map_hunter, Map_hunter_mind] = ftn_hunter_property_new(num_hunter, space_size,Map_total, P_h_jump, sensing_r_hunter)
%%  사냥꾼 위치 로딩
[numbers, strings, ini_pos_hunter] = xlsread('HUNTER_POSITION.xlsx');
in_lat = cell2mat(ini_pos_hunter(2: end, 2));
in_long = cell2mat(ini_pos_hunter(2: end, 3));

for k = 1: num_hunter
    p=in_lat(k); q = in_long(k);
[grid_x, grid_y] = ftn_lat_long_to_xy(p, q, space_size);
hunter_ini_xy(k, :) = [grid_x, grid_y];
%hunter_ini_xy(k, :) = [grid_y, grid_x]; %x 경도, y 위도
end % k 
%save hunter_ini_xy.mat hunter_ini_xy
for k = 1: num_hunter
 hunter(k).position = hunter_ini_xy(k,:);
    hunter(k).sensing_r = sensing_r_hunter;
    hunter(k).p_jump = P_h_jump;
end 

%% 사냥꾼의 위치 맵: "1" 이 사냥꾼을 나타낸다. 
map_hunter = zeros(space_size);
for k=1:num_hunter
map_hunter(hunter(k).position(1), hunter(k).position(2)) = 1;
end

%% 사냥꾼의 이동경로를 결정하기 위한 마음상태 맵
Map_hunter_mind = ones(space_size);  % 랜덤워크
Map_hunter_mind = Map_total;  % 멧돼지가 운동하는 경향성을 따라간다