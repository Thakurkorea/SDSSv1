function [boar, num_boar] = ftn_boar_mortality(boar, num_boar,space_size);
s = 0; death_index = [];
for num = 1: num_boar
if (boar(num).age == boar(num).max_mortality)  % �ִ����
    s = s + 1;
    death_index(s,1) = num;
end

end % for
boar(death_index) =[];
[a, num_boar] = size(boar);

