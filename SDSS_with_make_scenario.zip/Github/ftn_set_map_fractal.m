%%----------------------------
% ����Ż ���� �����
% H = 0 ~ 1
%----------------------------

function [Map_food,Map_water, Map_forest, Map_total] = ftn_set_map_fractal(space_size, H, boar_walking_noise);
%	N - space_size
%	H - fractal dimension (the bigger this is the smoother the landscape)

%randn('seed',0);
N = space_size;
A=zeros(N);
B=zeros(N);
m=N/2+1;
p=(H+1)/2;
[I,J]=meshgrid([-N/2+1:N/2], [-N/2+1:N/2]);
phases=2*pi*rand(N);
amp=(I.^2+J.^2).^(-p);
amp(N/2,N/2)=0;
As=amp.*exp(i*phases);

A=ifft2(As/N^2);
B=abs(A);
B=B/max(max(B));

Map_forest = B;
Map_water= zeros(space_size);
Map_food= zeros(space_size);
Map_total = double(Map_food) + double(Map_water) + double(Map_forest);
if boar_walking_noise >=0
    Map_total = (1-boar_walking_noise)*Map_total + boar_walking_noise*rand(space_size);
end 
    %
%     Map_total = 0.5*ones(space_size);
%
% surf(B), colormap(jet), shading interp
