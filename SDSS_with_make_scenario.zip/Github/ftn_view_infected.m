function [] = ftn_view_infected(boar, num_boar)
j = 0; 
for k=1:num_boar
    if boar(k).infection ==1
j = j+1;
Px_inf(j) = boar(j).position(1);
Py_inf(j) = boar(j).position(2);
%     else
%         flag = 0;
    end %j
end
if j > 0;
hold on 
h_inf = plot(Px_inf, Py_inf, 'ob','MarkerSize', 7, 'MarkerFaceColor',[0.8,0.1,0.7]);
drawnow
delete(h_inf);
hold off
else
    return
end
