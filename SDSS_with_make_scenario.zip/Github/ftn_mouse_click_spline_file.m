function [xs, ys]=ftn_mouse_click_spline_file(P_fense, x, y, n)
load Maps_takur.mat;
imagesc(Map_total);
axis([1 500 1 500])
hold on
% x = [];
% y = [];
% n =0;
% but = 1;
% while but == 1
% [xi,yi,but] = ginput(1);
% plot(xi,yi,'r.', 'MarkerSize', 12)
% n = n+1;
% x(n,1) = xi;
% y(n,1) = yi;
% end
% Interpolate with two splines and finer spacing.
t = 1:n;
ts = 1: 0.05: n;
xs = spline(t, x, ts);
ys = spline(t, y, ts);
% Plot the interpolated curve.
plot(xs,ys,'k-', 'LineWidth', 3);

xs = round(xs);
ys = round(ys);
hold off


for k = 1: length(xs)
Map_total(ys(k), xs(k)) = P_fense;
end
 %imagesc(Map_total);   
save Maps_fense.mat Map_total 
end 

