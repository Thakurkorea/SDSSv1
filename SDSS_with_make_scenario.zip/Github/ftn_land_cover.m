function [] = ftn_land_cover()
 web('new.html')