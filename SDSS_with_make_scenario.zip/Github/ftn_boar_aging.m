function [boar] = ftn_boar_aging(boar, num)
boar(num).age = boar(num).age +1; %  "1" --> 1 day  
if boar(num).infection == 1
boar(num).age_infection = boar(num).age_infection +1;
end