function  [bx, by] = ftn_avoid_from_hunter(bx,by,r,hunter)
% �Ÿ�r �̳��� ��ġ�ϰ� �ִ� ��ɲ۵��� ��ġ�� 1/r^2 ������ ������ �̵�

 n = length(hunter);
 temp = hunter;

 for i=1:n
   if ((bx-hunter(i).position(1))^2 + (by-hunter(i).position(2))^2 > r^2 )
      temp(i) =[]; 
   end
 end
 n1 = length(temp);

 tpx = 0; tpy = 0;
 for i=1:n1
     
     rt = norm([temp(i).position(1) temp(i).position(2)]);
     temp(i).position(1) = temp(i).position(1) - bx; 
     temp(i).position(2) = temp(i).position(2) - by; 
     
     temp(i).position(1) = - temp(i).position(1)/rt^3; 
     temp(i).position(2) = - temp(i).position(2)/rt^3; 
     
     tpx = tpx + temp(i).position(1);
     tpy = tpy + temp(i).position(2);
 end
 
 bx = tpx + bx;
 by = tpy + by;

end

