%function [] = ftn_mak_boar_ini_xy() 

load boar_ini_lat_long.mat;
for k = 1: length(boar_ini_lat_long)
 [grid_x, grid_y] = ftn_lat_long_to_xy(boar_ini_lat_long(k,1), boar_ini_lat_long(k, 2), space_size);
boar_ini_xy(k, 1) = grid_x;
boar_ini_xy(k, 2) = grid_y;
end % k 

% �������� ���� �����ϱ�
[boar, num_boar] = ftn_boar_del_in_north_area(boar, num_boar,Map_total, space_size);

%% �׸��׸���
hold on ;
im = imread('SKorea_1000.png');
imagesc(im)
ax = gca;
ax.YDir = 'reverse';
plot(boar_ini_xy(:, 1), boar_ini_xy(:,2), 'r*')
% plot(boar(1).position(2), boar(1).position(1), 'r*') 
% plot(boar(2).position(2), boar(2).position(1), 'r*') 
% plot(boar(3).position(2), boar(3).position(1), 'r*') 
