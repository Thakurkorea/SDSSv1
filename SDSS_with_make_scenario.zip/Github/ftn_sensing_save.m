function  [sens_map] = ftn_sensing_save(r,Map_total)
% map: matrix, position = x-y-axis from left-up 

L = size(Map_total);
sens_map = zeros(L(1)+2,L(2)+2); 

for i=1:L(1)+2
    for j=1:L(2)+2
       sens_map(i,j) = ftn_sensing(i,j,r,Map_total);
    end
end

end