% 시나리오 구조 시각화
function [] = ftn_check_scenario()
close all;
for k = 1: length(boar)
r(k,1) = boar(k).position(1);
w(k,1) = boar(k).position(2);

end
for k =1:length(hunter)
rh(k, 1) = hunter(k).position(1);
wh(k, 1) = hunter(k).position(2);

end
hold on;
imagesc(Map_total);
%plot(r, w, 'ro') % 멧돼지분포
plot(rh, wh, 'r*') % 사냥꾼분포