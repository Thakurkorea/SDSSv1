function [boar, num_boar] = ftn_boar_init(boar, num_boar,Map_total, space_size);

s = 0; death_index = [];
for num = 1: num_boar
x = boar(num).position(1);
y = boar(num).position(2);
if Map_total(x, y) == 0;
  s = s + 1;
    death_index(s,1) = num;
end
end %k
boar(death_index) =[];
[a, num_boar] = size(boar);
