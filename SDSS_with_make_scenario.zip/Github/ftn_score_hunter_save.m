function [score_hunter_mind] = ftn_score_hunter_save(hunter_x,hunter_y,sensing_r,Map_hunter_mind)

hx = hunter_x+1; hy = hunter_y+1;

score_hunter_mind = zeros(3);

[num_hunter_mind] = Map_hunter_mind(hx-1, hy+1); score_hunter_mind(1,1)= num_hunter_mind;
[num_hunter_mind] = Map_hunter_mind(hx-1, hy+0); score_hunter_mind(2,1)= num_hunter_mind;
[num_hunter_mind] = Map_hunter_mind(hx-1, hy-1); score_hunter_mind(3,1)= num_hunter_mind;
[num_hunter_mind] = Map_hunter_mind(hx+0, hy+1); score_hunter_mind(1,2)= num_hunter_mind;
[num_hunter_mind] = Map_hunter_mind(hx+0, hy+0); score_hunter_mind(2,2)= num_hunter_mind;
[num_hunter_mind] = Map_hunter_mind(hx+0, hy-1); score_hunter_mind(3,2)= num_hunter_mind;
[num_hunter_mind] = Map_hunter_mind(hx+1, hy+1); score_hunter_mind(1,3)= num_hunter_mind;
[num_hunter_mind] = Map_hunter_mind(hx+1, hy+0); score_hunter_mind(2,3)= num_hunter_mind;
[num_hunter_mind] = Map_hunter_mind(hx+1, hy-1); score_hunter_mind(3,3)= num_hunter_mind;

