function [] = ftn_output()

% 결과에서 엑셀 출력하기
if isfile('OUTPUT.xlsx') == 1
delete('OUTPUT.xlsx');
end 

load OUTPUT.mat
filename = 'OUTPUT.xlsx';
pop_size_boar_male = pop_size_boar - pop_size_boar_female;
A = [pop_size_boar, pop_size_boar_male, pop_size_boar_female];
writematrix(A, filename, 'Sheet', 1);

for k = 1: length(boar)
grid_x = boar(k).position(1);
grid_y = boar(k).position(2);
[out_lat, out_long] = ftn_xy_to_lat_long(grid_x, grid_y, 500);
Boar_lat(k, :) = out_lat;
Boar_long(k, :) = out_long;
end

B = [Boar_lat, Boar_long];
writematrix(B, filename, 'Sheet', 2);

load Boar_spread.mat
C = [district_name, boar_frequency];
 writecell(C, filename, 'Sheet', 3);